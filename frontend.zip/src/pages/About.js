import React from "react";
import "../components/Books.css";
function About() {
  return (
    <div className="About">
      <div className="FirstContent">
        <h1>Who Are We?</h1>
      </div>
      <h1>
        <p className="Info1">
          I will never look away If I lose it all, lose it all, lose it all If I
          lose it all outside the wall Live to die another
          day.gbshdfbsjbfhsjhdgggsd
        </p>
      </h1>
      <br />
      <h2>This is about page.</h2>
    </div>
  );
}

export default About;
