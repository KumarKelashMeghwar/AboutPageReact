import React from "react";
import "../components/Books.css";
function Checkout() {
  return (
    <div className="Checkout">
      <div className="FirstContent">
        <h1>CHECKOUT</h1>
      </div>
      <h1>
        <p className="Info1">
          TEST PAGE :)
        </p>
      </h1>
      <br />
      <h2>This is a test page for checkout.</h2>
    </div>
  );
}

export default Checkout;
